package Model;

public class Token {

	private String token;
	
	public Token(String status){
        this.token = status;
    }
 
    public String getStatus() {
        return token;
    }
}
